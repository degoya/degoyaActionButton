<?php
$_lang['degoyaActionButton.title'] = 'degoyaActionButton';
$_lang['degoyaActionButton.msg.confirm.title'] = 'Aktion durchführen?';
$_lang['degoyaActionButton.msg.confirm.copy'] = 'Soll die Aktion wirklich ausgeführt werden?';
$_lang['degoyaActionButton.btn.caption'] = 'Snippet [[+snippetname]] ausführen';
$_lang['degoyaActionButton.btnCaptionTitle'] = 'Button-Beschriftung';
$_lang['degoyaActionButton.btnCaptionHelp'] = 'Geben Sie die Beschriftung für den Button ein';
$_lang['degoyaActionButton.saveTitle'] = 'Ressource speichern';
$_lang['degoyaActionButton.saveHelp'] = 'Ressource vor dem Ausführen des Snippets speichern';
$_lang['degoyaActionButton.ajax.success.title'] = 'Aktion erfolgreich';
$_lang['degoyaActionButton.ajax.success.msg'] = 'Das Snippet: [[+snippetname]] wurde mit ResourceID: [[+resource]] erfolgreich ausgeführt.';
$_lang['degoyaActionButton.ajax.error.title'] = 'Aktion fehlgeschlagen';
$_lang['degoyaActionButton.ajax.error.msg'] = 'Das Snippet: [[+snippetname]] mit ResourceID: [[+resource]] wurde <strong>nicht</strong> erfolgreich ausgeführt.';
$_lang['degoyaActionButton.ajax.error.msg.snippet'] = 'Das Snippet: [[+snippetname]] wurde <strong>nicht</strong> erfolgreich ausgeführt.';
