----------------------------
Extra: degoyaActionButton
----------------------------
Version: 1.0.0beta7
Released: 2015-09-18
Author: Alexander Herling / DEGOYA medienkommunikation oHG <a.herling@degoya.de>
License: GNU GPLv2 (or later at your option)

About
A custom Button template variable field type for MODX Revolution (2.3+).
You can use to call Snippets from the Resource in the Manager to fire Actions.


Features
This custom MODX Revolution TV that can be used to fire Snippet calls from on a Resource in the Manager.


Installation
Install Package via MODX Package Management.
Then simply create a new TV with the input type type set to degoyaActionButton.
Enter the snippet name you like to trigger as defaultvalue.
If you like you can set a Caption for the Button in the TV Options.
If you leave the caption option empty, the caption from the lexicon will be used.

That's it, have fun!

