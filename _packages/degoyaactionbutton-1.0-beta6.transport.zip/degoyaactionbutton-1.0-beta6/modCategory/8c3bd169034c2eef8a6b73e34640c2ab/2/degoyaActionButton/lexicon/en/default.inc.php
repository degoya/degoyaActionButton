<?php
$_lang['degoyaActionButton.title'] = 'degoyaActionButton';
$_lang['degoyaActionButton.msg.confirm.title'] = 'Execute Action?';
$_lang['degoyaActionButton.msg.confirm.copy'] = 'Do you really like to execute this Action?';
$_lang['degoyaActionButton.btn.caption'] = 'Run Snippet [[+snippetname]]';
$_lang['degoyaActionButton.ajax.success.title'] = 'Success';
$_lang['degoyaActionButton.ajax.success.msg'] = 'Successful running Snippet: [[+snippetname]] with ResourceID: [[+resource]]';
$_lang['degoyaActionButton.ajax.error.title'] = 'Error';
$_lang['degoyaActionButton.ajax.error.msg'] = '<strong>Error</strong> running Snippet: [[+snippetname]] with ResourceID: [[+resource]]';
$_lang['degoyaActionButton.ajax.error.msg.snippet'] = '<strong>Error</strong> running Snippet: [[+snippetname]] - Snippet Error';
