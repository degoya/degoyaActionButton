----------------------------
Extra: degoyaActionButton
----------------------------
Version: 1.0.0beta9
Released: 2015-10-03
Author: Alexander Herling / DEGOYA medienkommunikation oHG <a.herling@degoya.de>
License: GNU GPLv2 (or later at your option)

About
A custom Button template variable field type for MODX Revolution (2.3+).
You can use to call Snippets from the Resource in the Manager to fire Actions.


Features
This custom MODX Revolution TV that can be used to fire Snippet calls from on a Resource in the Manager.


Installation
Install Package via MODX Package Management.
Then simply create a new TV with the input type type set to degoyaActionButton.
Select the snippet you like to trigger, the snippet must return 'success'.
If you like you can set a Caption for the Button in the TV Options.
If you leave the caption option empty, the caption from the lexicon will be used.
Added first version of resource save, maybe still not working with some extras.
Select if you like to have a Confirmation Dialog befor the snippet is called.
Select to display Result Message (Success/Error).


That's it, have fun!

